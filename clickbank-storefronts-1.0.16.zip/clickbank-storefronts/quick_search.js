function cs_quick_search(search_page, criteria)
{
    window.location = search_page + encodeURIComponent(criteria);
}
