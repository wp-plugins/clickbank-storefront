<?php

/*
Plugin Name: Clickbank Storefronts
Description: This plugin allows you to host a World Class featured Clickbank Storefront (Mall) to your blog with just few clicks.
Author: CBproAds.com
Version: 1.0.16
Author URI: http://www.cbproads.com/
Plugin URI: http://www.cbproads.com/clickbank_storefront_wordpress_plugin.asp
*/

$GLOBALS['cs_plugin_version'] = '1.0.16';
$GLOBALS['cs_plugin_filename'] = 'clickbank-storefronts/clickbank-storefronts.php';
$GLOBALS['cs_plugin_dir'] = plugin_dir_path(__FILE__);
$GLOBALS['cs_plugin_url'] = plugin_dir_url(__FILE__);
if (substr($GLOBALS['cs_plugin_url'], -1) === '/') {
    $GLOBALS['cs_plugin_url'] = substr($GLOBALS['cs_plugin_url'], 0, -1);
}

$GLOBALS['cs_available_tags'] = array('h1', 'h2', 'h3', 'strong', 'div', 'span');
$GLOBALS['cs_options'] = array(
    'cs_user_id' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'Your CBproAds Account ID',
        'default' => '15750',
    ),
    'cs_show_price' => array(
        'req' => true,
        'type' => 'checkbox',
        'label' => 'Show Price',
        'default' => '0', // 0 or 1
    ),
    'cs_items_per_page' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'Items per Page',
        'default' => '12',
    ),
    'cs_image_size' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'Image Size',
        'default' => '175',
    ),
    'cs_image_margin' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'Image Margin (left/right)',
        'default' => '30',
    ),
    'cs_switch_view' => array(
        'req' => true,
        'type' => 'select',
        'vals' => array(
            'ti' => 'Title & Image',
            'tdi' => 'Title, Descr. & Image',
            'tdli' => 'Title, Descr., Long Descr. & Image',
            'td' => 'Title & Descr.'),
        'label' => 'Switch View Default View',
        'default' => 'ti',
    ),
    'cs_rank' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'Show Products Only Having Rank Value at Least',
        'default' => '50',
    ),
    'cs_gravity' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'Show Products Only Having Gravity Greater than',
        'default' => '1',
    ),
    'cs_products_page' => array(
        'req' => false,
        'type' => 'select',
        'vals' => array(
            '' => 'No Page'),
        'label' => 'CB Categories Widget Output Page',
        'default' => '',
    ),
    'cs_cats_to_omit' => array(
        'req' => false,
        'type' => 'select',
        'vals' => array(),
        'label' => 'Categories to Omit<br />(CB Categories Widget)',
        'default' => '',
    ),
    // Bestselling / Featured / Popular
    'cs_view_other' => array(
        'req' => true,
        'type' => 'select',
        'vals' => array(
            'ti' => 'Title with Image',
            'tdi' => 'Title, Description & Image',
            'tdli' => 'Title, Description, Long Description & Image',
            'td' => 'Title & Description'),
        'label' => 'Bestselling / Featured / Popular View',
        'default' => 'ti',
    ),
    'cs_bestselling_num' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'No of Products to Display in Best Selling Section',
        'default' => '12',
    ),
    'cs_featured_num' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'No of Products to Display in Featured (Custom Products) Section',
        'default' => '12',
    ),
    'cs_featured_ids' => array(
        'req' => false,
        'type' => 'text',
        'label' => 'Featured Product IDs',
        'default' => '',
    ),
    'cs_popular_num' => array(
        'req' => true,
        'type' => 'int',
        'label' => 'No of Products to Display in Popular Products Section',
        'default' => '12',
    ),
);
$GLOBALS['cs_ad_options'] = array( // Advanced options
    'cs_title_tag' => array(
        'req' => true,
        'type' => 'select',
        'vals' => $GLOBALS['cs_available_tags'],
        'label' => 'Product Title HTML Tag',
        'default' => 'h3',
    ),
    'cs_title_style' => array(
        'req' => false,
        'type' => 'text',
        'label' => 'Product Title CSS Style',
        'default' => 'line-height: 1.3; font-size: 130%; font-weight: bold; padding: 0.4em;',
    ),
    'cs_subtitle_tag' => array(
        'req' => true,
        'type' => 'select',
        'vals' => $GLOBALS['cs_available_tags'],
        'label' => 'Product Description HTML Tag',
        'default' => 'strong',
    ),
    'cs_subtitle_style' => array(
        'req' => false,
        'type' => 'text',
        'label' => 'Product Description CSS Style',
        'default' => 'font-size: 120%; padding-bottom: 1em;',
    ),
);
$GLOBALS['cs_option_names'] = array_merge(
    array_keys($GLOBALS['cs_options']), array_keys($GLOBALS['cs_ad_options']));

$GLOBALS['cs_tw_defaults'] = array(
    'title' => 'Categories',
    'title_css' => '',
    'thumb_size' => 'large',
    'thumb_num' => 4,
    'bg_color' => 'F9F9F9',
    'border_color' => 'D6D6D6');


require_once $GLOBALS['cs_plugin_dir'].'admin.inc.php'; // Defines all functions for Admin Panel
require_once $GLOBALS['cs_plugin_dir'].'functions.inc.php'; // Defines all functions (Product List)
require_once $GLOBALS['cs_plugin_dir'].'widgets.inc.php'; // Defines all widgets


if (!session_id()) session_start();

// Fill session with current values & global values
$_SESSION['cs_plugin_url'] = plugins_url('', __FILE__);
foreach ($GLOBALS['cs_option_names'] as $o) {
    if ($o !== 'cs_switch_view' || $_SESSION[$o] == '') {
        $_SESSION[$o] = get_option($o);
    }
}
$_SESSION['cs_switch_view_vals'] = $GLOBALS['cs_options']['cs_switch_view']['vals'];

// Attack WP actions, filters, hooks
register_activation_hook(__FILE__, 'cs_activate');
register_deactivation_hook(__FILE__, 'cs_deactivate');
if (is_admin()) {
    add_action('admin_menu', 'cs_add_to_menu');
    /*if (trim($_GET['page']) == 'cs_menu') {
        add_action('admin_head', 'cs_option_js');
    }*/
} else {
    if (isset($_GET['id']) && ($_GET['id'] = trim($_GET['id'])) != '') {
        setcookie('cs_user_id', $_GET['id'], time()+60*60*24*365, '/', cs_get_site_domain());
        $_SESSION['cs_user_id'] = $_COOKIE['cs_user_id'] = $_GET['id'];
    } elseif (isset($_COOKIE['cs_user_id'])) {
        $_SESSION['cs_user_id'] = $_COOKIE['cs_user_id'];
    }
    
    if (isset($_GET['tid']) && ($_GET['tid'] = trim($_GET['tid'])) != '') {
        setcookie('cs_tid', $_GET['tid'], time()+60*60*24*365, '/', cs_get_site_domain());
        $_SESSION['cs_tid'] = $_COOKIE['cs_tid'] = $_GET['tid'];
    } elseif (isset($_COOKIE['cs_tid'])) {
        $_SESSION['cs_tid'] = $_COOKIE['cs_tid'];
    }
}

add_shortcode('clickbank-storefront-products', 'cs_show_filter');
add_shortcode('clickbank-storefront-bestselling', 'cs_show_bestselling');
add_shortcode('clickbank-storefront-featured', 'cs_show_featured');
add_shortcode('clickbank-storefront-popular', 'cs_show_popular');
/*if ($_SESSION['cs_show_storefront_after_posts'] != 'no') {
    add_filter('the_posts', 'cs_show_products');
}*/

// Add settings link on plugin page
add_filter('plugin_action_links_'.$GLOBALS['cs_plugin_filename'], 'cs_settings_link');

// Add widgets
add_action("widgets_init", 'cs_register_widgets');

// Get categories for all further calls
cs_get_categories((isset($_GET['cs_category']) ? $_GET['cs_category'] : null));


wp_register_style('cs_stylesheet', $GLOBALS['cs_plugin_url'].'/style.css');
wp_enqueue_style('cs_stylesheet');

wp_enqueue_script(
    'cs_script_search',
    $GLOBALS['cs_plugin_url'].'/quick_search.js',
    array(),
    $GLOBALS['cs_plugin_version']);
?>