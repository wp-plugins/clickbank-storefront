<?php
  
require_once $GLOBALS['cs_plugin_dir'].'xmldb.inc.php';


/**
* Register widgets
* 
*/
function cs_register_widgets()
{
    wp_register_sidebar_widget(
        'cs_widget_cats',
        'CB Categories Widget',
        'cs_widget_cats');
    wp_register_sidebar_widget(
        'cs_widget_horizontal_cats',
        'CB Categories Widget (Horizontal)',
        'cs_widget_horizontal_cats');
    wp_register_sidebar_widget(
        'cs_widget_search',
        'CB Search Widget',
        'cs_widget_search');
    
    register_widget('cs_widget_thumb_cats');
}

/**
* Widget for categories
* 
* @param mixed $args
*/
function cs_widget_cats($args)
{
    //cs_widget_search($args);
    
    $cats = cs_get_categories();
    
    // Link to category page
    $cat_page = cs_get_products_page('cs_category', '');
    
    // Output
    echo $args['before_widget'];
    foreach ($cats['cats'] as $cat_id => $cat) {
        if (!isset($_SESSION['cs_cats_to_omit'][$cat_id])) {
            echo $args['before_title'], htmlspecialchars($cat['name']), $args['after_title'];
            foreach ($cat['subcats'] as $sub_id => $subcat) {
                $name_html = htmlspecialchars($subcat['name']);
                
                if (isset($subcat['selected']) && $subcat['selected']) {
                    echo "<strong>&raquo; $name_html</strong>";
                } else {
                    echo "<a href=\"$cat_page", ($cat_page !== '#' ? $sub_id : ''), "\">",
                        "$name_html</a>";
                }
                echo "<br />\n";
            }
            echo "<br />\n";
        }
    }
    echo $args['after_widget'];
}

/**
* Horizontal widget for categories
* 
* @param mixed $args
*/
function cs_widget_horizontal_cats($args)
{
    $cats = cs_get_categories();
    
    // Link to category page
    $cat_page = cs_get_products_page('cs_category', '');
    
    // Output
    echo $args['before_widget'];
    
    $cats_per_column = 70;
    $columns = 4;
    
    $i = 0;
    $cols = 0;
    $first = true;
    echo "<div style=\"display: table; width: 100%;\">\n";
    foreach ($cats['cats'] as $cat_id => $cat) {
        if (!isset($_SESSION['cs_cats_to_omit'][$cat_id])) {
            if ($i >= $cats_per_column) {
                echo "</div>\n";
                $cols++;
            }
            if ($first ||
                $i >= $cats_per_column && $cols % $columns === 0)
            {
                if ($cols !== 0) echo "</div>\n<br />\n";
                echo "<div style=\"display: table-row; vertical-align: top; ",
                    "text-align: center; width: 100%; margin-bottom: 1em;\">\n";
            }
            if ($first || $i >= $cats_per_column) {
                echo "<div style=\"display: table-cell; width: 25%; padding-right: 1em; "
                    . "text-align: left;\">\n";
                /*if ($first) {
                    cs_widget_search($args, false);
                    $i = 7;
                } else {*/
                $i = 0;
                #}
            }
            if ($first) $first = false;
            echo $args['before_title'], htmlspecialchars($cat['name']), $args['after_title'],
                "<br />\n";
            $i += 2;
            
            foreach ($cat['subcats'] as $sub_id => $subcat) {
                $name_html = htmlspecialchars($subcat['name']);
                
                if (isset($subcat['selected']) && $subcat['selected']) {
                    echo "<strong>&raquo; $name_html</strong>";
                } else {
                    echo "<a href=\"$cat_page", ($cat_page !== '#' ? $sub_id : ''), "\">",
                        "$name_html</a>";
                }
                echo "<br />\n";
                
                $i++;
            }
        }
    }
    echo "</div>\n",
        "</div>\n",
        "</div>\n",
        $args['after_widget'];
}

/**
* Widget for quick search
* 
* @param mixed $args
*/
function cs_widget_search($args, $separate_widget = true)
{
    $search_page = cs_get_products_page('cs_keywords', '');
    #$search_page = cs_get_products_page();
    
    // Output
    echo ($separate_widget ? $args['before_widget'] : ''),
        $args['before_title'], 'Search Products', $args['after_title'], "<br />\n",
        #"<form method=\"GET\" action=\"", htmlspecialchars($search_page), "\">\n",
        "<input type=\"text\" id=\"cs_quick_search\" name=\"cs_keywords\" value=\"$_GET[cs_keywords]\" />\n",
        #"<input type=\"submit\" value=\"Search\" />\n",
        "<input type=\"submit\" value=\"Search\" onclick=\"cs_quick_search('",
        htmlspecialchars($search_page), "', jQuery('#cs_quick_search').val()); return false\" />\n",
        #"</form>\n",
        ($separate_widget ? $args['after_widget'] : "<br />\n<br />\n");
}

/**
* Thumbnails widget for categories
*/
class cs_widget_thumb_cats extends WP_Widget {
    function __construct()
    {
        $widget_ops = array(
            'classname' => 'cs_widget_thumb_cats',
            /*'description' => 'Displays your upcoming posts to tease your readers'*/);
        $control_ops = array('id_base' => 'cs_widget_thumb_cats');
        $this->WP_Widget(
            'cs_widget_thumb_cats',
            'CB Categories Widget (Horizontal Thumbnails)',
            $widget_ops, $control_ops);
    }
    
    // Extract Args //
    function widget($args, $instance)
    {
        global $cs_plugin_url, $cs_plugin_version, $cs_tw_defaults;
        
        foreach ($cs_tw_defaults as $k => $v) {
            if (!isset($instance[$k])) {
                $instance[$k] = $cs_tw_defaults[$k];
            }
        }
        $thumb_num = (int)$instance['thumb_num'];
        
        // Widget output //
        $cats = cs_get_categories();
        // Link to category page
        $cat_page = cs_get_products_page('cs_category', '');
        if ($instance['thumb_size'] === 'large') {
            $cat_width = 142;
            $cat_height = 160;
            $arrow_left = 'http://clickbankproads.com/images/thumb_arrow_left.png';
            $arrow_left_hover = 'http://clickbankproads.com/images/thumb_arrow_left_hover.png';
            $arrow_right = 'http://clickbankproads.com/images/thumb_arrow_right.png';
            $arrow_right_hover = 'http://clickbankproads.com/images/thumb_arrow_right_hover.png';
        } else {
            $cat_width = 101;
            $cat_height = 115;
            $arrow_left = 'http://clickbankproads.com/images/thumb_arrow_small_left.png';
            $arrow_left_hover = 'http://clickbankproads.com/images/thumb_arrow_small_left_hover.png';
            $arrow_right = 'http://clickbankproads.com/images/thumb_arrow_small_right.png';
            $arrow_right_hover = 'http://clickbankproads.com/images/thumb_arrow_small_right_hover.png';
        }
        
        // Output
        $preview = array(
            "preview[0]=".hsc(rawurlencode(str_replace('/', '^', $arrow_left_hover))),
            "preview[1]=".hsc(rawurlencode(str_replace('/', '^', $arrow_right_hover))));
        $preview_count = 2;
        foreach ($cats['cats'] as $cat_id => $cat) {
            if (!isset($_SESSION['cs_cats_to_omit'][$cat_id])) {
                if ($instance['thumb_size'] === 'large') $thumb_grey = $cat['thumbnail_grey'];
                else $thumb_grey = $cat['thumbnail_small_grey'];
                $preview[] = "preview[$preview_count]="
                    . hsc(rawurlencode(str_replace('/', '^', $thumb_grey)));
                $preview_count++;
            }
        }
        echo "<script id=\"cs_thumbnails_script\" type=\"text/javascript\" ",
            "src=\"$_SESSION[cs_plugin_url]/thumbnails.js?",
            implode('&amp;', array_merge($preview,
            array("thumb_num=$thumb_num",
            "cat_width=$cat_width",
            "cat_height=$cat_height",
            "version=$cs_plugin_version"))),
            "\">  ",
            "</script>\n";
        ?>
        <?php echo $args['before_widget'] ?>
        <?php if ($instance['title'] != ''): ?>
            <?php if ($instance['title_css'] == ''): ?>
                <?php echo $args['before_title'], hsc($instance['title']), $args['after_title'] ?>
            <?php else: ?>
                <div style="<?php echo $instance['title_css'] ?>"><?php echo hsc($instance['title']) ?></div>
            <?php endif ?>
        <?php endif ?>
        
        <div style="width: 100%; white-space: nowrap; text-align: center">
            <div style="display: block; width: <?php echo $thumb_num*$cat_width + 126 ?>px">
                <div class="cs_tw_larrow">
                    <div style="height: <?php echo $cat_height ?>px">
                        <img src="<?php echo $arrow_left ?>"
                        alt="" onclick="if (typeof cs_tw_scroll !== 'undefined') cs_tw_scroll('left')"
                        onmouseover="this.src='<?php echo $arrow_left_hover ?>'"
                        onmouseout="this.src='<?php echo $arrow_left ?>'">
                    </div>
                </div>
                <div class="cs_tw_frame"
                style="width: <?php echo $thumb_num*$cat_width ?>px; text-align: left">
                    <div class="cs_tw_cats">
                        <?php $i = 0; ?>
                        <?php foreach ($cats['cats'] as $cat_id => $cat): ?>
                            <?php if (!isset($_SESSION['cs_cats_to_omit'][$cat_id])):
                                if ($instance['thumb_size'] === 'large') {
                                    $thumb_main = hsc($cat['thumbnail_main']);
                                    $thumb_grey = hsc($cat['thumbnail_grey']);
                                } else {
                                    $thumb_main = hsc($cat['thumbnail_small_main']);
                                    $thumb_grey = hsc($cat['thumbnail_small_grey']);
                                }
                                ?>
                                <div class="cs_tw_cat"
                                onmouseover="if (typeof cs_tw_cat_mouseover !== 'undefined') cs_tw_cat_mouseover(this, '<?php echo $thumb_grey ?>', <?php echo $cat_id ?>, <?php echo $i ?>)"
                                onmouseout="if (typeof cs_tw_cat_mouseout !== 'undefined') cs_tw_cat_mouseout(this, '<?php echo $thumb_main ?>', <?php echo $cat_id ?>)"
                                style="height: <?php echo $cat_height ?>px">
                                    <img id="cs_tw_img_<?php echo $cat_id ?>"
                                    src="<?php echo $thumb_main ?>"
                                    alt="<?php echo hsc($cat['name']) ?>">
                                    <?php
                                    /*$preview[] = "preview[$preview_count]="
                                        . str_replace('/', '^', $thumb_grey);
                                    $preview_count++;*/
                                    ?>
                                </div>
                                <?php $i++; ?>
                            <?php endif ?>
                        <?php endforeach ?>
                    </div>
                    <?php foreach ($cats['cats'] as $cat_id => $cat): ?>
                        <?php if (!isset($_SESSION['cs_cats_to_omit'][$cat_id])):
                            if ($instance['thumb_size'] === 'large') {
                                $thumb_main = hsc($cat['thumbnail_main']);
                                $thumb_grey = hsc($cat['thumbnail_grey']);
                            } else {
                                $thumb_main = hsc($cat['thumbnail_small_main']);
                                $thumb_grey = hsc($cat['thumbnail_small_grey']);
                            }
                            ?>
                            <div class="cs_tw_subcats" id="cs_tw_subcats_<?php echo $cat_id ?>"
                            onmouseover="if (typeof cs_tw_subcats_mouseover !== 'undefined') cs_tw_subcats_mouseover(this, <?php echo $cat_id ?>)"
                            onmouseout="if (typeof cs_tw_subcats_mouseout !== 'undefined') cs_tw_subcats_mouseout(this, '<?php echo $thumb_main ?>', <?php echo $cat_id ?>)"
                            style="background: #<?php echo $instance['bg_color'] ?>; border-color: #<?php echo $instance['border_color'] ?>;">
                                <?php foreach ($cat['subcats'] as $sub_id => $subcat): ?>
                                    <!--img src="<?php echo $cs_plugin_url ?>/little_right_arrow.gif" alt=""-->
                                    <img src="http://clickbankproads.com/images/arrow_small.png" alt="">
                                    <?php if (isset($subcat['selected']) && $subcat['selected']): ?>
                                        <strong><?php echo hsc($subcat['name']) ?></strong>
                                    <?php else: ?>
                                        <a href="<?php echo $cat_page, ($cat_page !== '#' ? $sub_id : '') ?>">
                                            <?php echo hsc($subcat['name']) ?></a>
                                    <?php endif ?>
                                    <br />
                                <?php endforeach ?>
                            </div>
                        <?php endif ?>
                    <?php endforeach ?>
                </div>
                <div class="cs_tw_rarrow">
                    <div style="height: <?php echo $cat_height ?>px">
                        <img src="<?php echo $arrow_right ?>" alt=""
                        onclick="if (typeof cs_tw_scroll !== 'undefined') cs_tw_scroll('right', <?php echo ceil(count($cats['cats']) / $thumb_num) ?>)"
                        onmouseover="this.src='<?php echo $arrow_right_hover ?>'"
                        onmouseout="this.src='<?php echo $arrow_right ?>'">
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $args['after_widget'] ?>
        <?php
    }
    
    // Update Settings //
    function update($new_instance, $old_instance)
    {
        return $new_instance;
    }
    
    // Widget Control Panel //
    function form($instance)
    {
        global $cs_tw_defaults;
        
        $instance = wp_parse_args((array)$instance, $cs_tw_defaults); ?>
        
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <?php _e('Title') ?>:
            </label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
            name="<?php echo $this->get_field_name('title'); ?>"
            type="text" value="<?php echo $instance['title']; ?>" /><br />
            <span class="description">Leave blank to disable</span>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('title_css'); ?>">
                <?php _e('Title CSS Style (Advanced)') ?>:
            </label>
            <input class="widefat" id="<?php echo $this->get_field_id('title_css'); ?>"
            name="<?php echo $this->get_field_name('title_css'); ?>"
            type="text" value="<?php echo $instance['title_css']; ?>" /><br />
            <span class="description">
                Example:
                <span style="font-style: normal; font: 8pt Courier">
                    font: 18pt Georgia; color: #FF44CC;
                </span><br />
                Leave blank to show the title as a normal widget title (using WP theme's style)
            </span>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('thumb_size'); ?>">Thumbnail Size:</label>
            <select id="<?php echo $this->get_field_id('thumb_size'); ?>"
            name="<?php echo $this->get_field_name('thumb_size'); ?>"
            class="widefat" style="width:100%">
                <?php
                $values = array('large' => 'Large', 'small' => 'Small');
                foreach ($values as $val => $text):
                ?>
                    <option value="<?php echo $val ?>" <?php selected($val, $instance['thumb_size']) ?>>
                        <?php echo hsc($text) ?>
                    </option>
                <?php endforeach ?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('thumb_num'); ?>">Show Thumbnails at Once:</label>
            <select id="<?php echo $this->get_field_id('thumb_num'); ?>"
            name="<?php echo $this->get_field_name('thumb_num'); ?>"
            class="widefat" style="width:100%">
                <?php
                $values = array(3 => '3', 4 => '4', 5 => '5', 6 => '6', 7 => '7',
                    8 => '8', 9 => '9', 10 => '10', 11 => '11', 12 => '12');
                foreach ($values as $val => $text):
                ?>
                    <option value="<?php echo $val ?>" <?php selected($val, $instance['thumb_num']) ?>>
                        <?php echo hsc($text) ?>
                    </option>
                <?php endforeach ?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('bg_color'); ?>">
                <?php _e('Subcats Menu BG Color') ?>:
            </label>
            <input class="widefat" id="<?php echo $this->get_field_id('bg_color'); ?>"
            name="<?php echo $this->get_field_name('bg_color'); ?>"
            type="text" value="<?php echo $instance['bg_color']; ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('border_color'); ?>">
                <?php _e('Subcats Menu Border Color') ?>:
            </label>
            <input class="widefat" id="<?php echo $this->get_field_id('border_color'); ?>"
            name="<?php echo $this->get_field_name('border_color'); ?>"
            type="text" value="<?php echo $instance['border_color']; ?>" />
        </p>
        <?php
    }
}

?>