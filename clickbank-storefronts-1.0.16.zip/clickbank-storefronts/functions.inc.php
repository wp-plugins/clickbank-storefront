<?php

if (isset($GLOBALS['cs_plugin_dir'])) {
    require_once $GLOBALS['cs_plugin_dir'].'xmldb.inc.php';
} else {
    require_once 'xmldb.inc.php';
}


/**
* Remove <![CDATA[ and ]]> tags if exist
* 
* @param string $data
* @return string
*/
function  cs_cdata($data)
{
    if (substr($data, 0, 9) === '<![CDATA[' && substr($data, -3) === ']]>') {
        $data = substr($data, 9, -3);
    }
    
    return $data;
}

/**
* Return formatted title
* 
* @param string $title
* @param bool $include_css_js
* @return string
*/
function cs_product_title_fmt($title, $link, $include_css_js = false)
{
    return (!$include_css_js
            ? "<$_SESSION[cs_title_tag]"
            . ($_SESSION['cs_title_style'] != ''
                ? " style=\"display: inline-block; "
                . ($_SESSION['cs_title_tag'] === 'div' ? 'text-align: center; ' : '')
                . "$_SESSION[cs_title_style]\""
                : '')
            . ">"
            : '')
        . "<a target=\"_blank\" href=\"$link\" rel=\"nofollow\">"
        . $title
        . "</a>"
        . (!$include_css_js
            ? "</$_SESSION[cs_title_tag]>"
            : '');
}

/**
* Get all CSS and JS code
* 
* @param int $totalp
* @param int $items_per_page
*/
function cs_get_css_js($totalp, $items_per_page)
{
    global $cs_plugin_version;
    
    #wp_register_style('cs_stylesheet', $_SESSION['cs_plugin_url'].'/style.css');
    #wp_enqueue_style('cs_stylesheet');
    if ($totalp > $items_per_page) cs_show_paging_css();
    
    wp_enqueue_script(
        'cs_script',
        $_SESSION['cs_plugin_url'].'/init.js'
        . '?plugin_url='.htmlspecialchars($_SESSION['cs_plugin_url']),
        array('jquery'),
        $cs_plugin_version);
}

/**
* Good htmlspecialchars
* 
* @param mixed $str
* @return string
*/
function hsc($str)
{
    return htmlspecialchars($str, ENT_QUOTES);
}

/**
* Return HTML product list to insert into post / page / etc
* 
* @param string $section
* @param int $user_id
* @param int $criteria
* @param int $page
* @param int $product_number
* @return string
*/
function cs_show($section, $user_id, $criteria = null, $page = 1, $product_number = null)
{
    if (in_array($section, array('category', 'search'), true)) {
        $cur_view = $_SESSION['cs_switch_view'];
    } else {
        $cur_view = $_SESSION['cs_view_other'];
    }
    
    if ($cur_view === 'tdi') {
        $item_width = (int)$_SESSION['cs_image_size'] + ((int)$_SESSION['cs_image_margin'])*2;
        $item_height = (int)$_SESSION['cs_image_size'] + 345;
        $product_height = (int)$_SESSION['cs_image_size'] + 319;
    } elseif ($cur_view === 'ti') {
        $item_width = (int)$_SESSION['cs_image_size'] + ((int)$_SESSION['cs_image_margin'])*2;
        $item_height = (int)$_SESSION['cs_image_size'] + 226;
        $product_height = (int)$_SESSION['cs_image_size'] + 200;
    }
    
    $p_data = cs_get_items($section, $user_id, $criteria,
        ($product_number !== null ? $product_number : $_SESSION['cs_items_per_page']),
        $page, false);
    if (empty($p_data['posts'])) {
        $item_list = '<strong>Sorry, no results.</strong>';
    } else {
        $item_list = '';
        foreach ($p_data['posts'] as $p) {
            if (in_array($cur_view, array('tdli', 'td'), true)) {
                $item_list .= <<<HD
<!--[if lte IE 8]>
<div class="cs_socials cs_socials_ie8" style="float: right">
<![endif]-->
<!--[if gt IE 8]><!---->
<div class="cs_socials" style="float: right">
<!--<![endif]-->\n
HD;
            } else {
                $item_list .= <<<HD
<div class="cs_inline_product">
<div class="cs_inline_product_div" style="width: {$item_width}px; height: {$item_height}px">
<!--[if lte IE 8]>
<div class="cs_socials cs_socials_ie8" style="float: right; padding-right: 0.6em; text-align: right">
<![endif]-->
<!--[if gt IE 8]><!---->
<div class="cs_socials" style="float: right; padding-right: 0.8em; text-align: right">
<!--<![endif]-->\n
HD;
            }
            $item_list .= <<<ITEM
<!--div class="cs_fb">
  <div class="fb-like" data-href="$p[target_url]" data-send="false"
  data-layout="button_count" data-width="150" data-show-faces="false"></div>
</div-->
&nbsp;
<span class="cs_twitter">
  <a href="https://twitter.com/share" class="twitter-share-button"
  data-url="$p[target_url]" data-text="Share">Share</a>
</span>
ITEM;
            $item_list .= "</div>\n";
            if (in_array($cur_view, array('tdli', 'td'), true)) {
                $item_list .=
                    /*"<span class=\"cs_pr_title_link\" onclick=\"window.open('$p[target_url]')\">"
                    . "$p[post_title]</span><br />\n"*/
                    "$p[post_title]<br />\n"
                    . "$p[post_content]<br />\n"
                    . "<hr />\n";
            } else {
                $item_list .=
                    "<div class=\"cs_ip_table\" style=\"width: 100%; height: {$product_height}px\">\n"
                    . "<div class=\"cs_ip_tr\">\n"
                    . "<div class=\"cs_ip_td\" style=\"text-align: left\">\n"
                    . "<div style=\"text-align: center\">"
                    #. "<span class=\"cs_pr_title_link\" onclick=\"window.open('$p[target_url]')\">"
                    . "$p[post_title]"
                    #. "</span>"
                    . "</div>\n"
                    . "$p[post_content]"
                    . "</div>\n" // cs_ip_td
                    . "</div>\n" // cs_ip_tr
                    . "</div>\n" // cs_ip_table
                    . "</div>\n" // cs_inline_product_div
                    . "</div>\n"; // cs_inline_product
            }
        }
    }
    if (in_array($cur_view, array('tdi', 'ti'), true)) {
        $item_list .= "<br /><br />\n";
    }
    
    $cs = '';
    if ($section !== 'search') {
        $cs .= <<<SOCIALS
<!--[if lte IE 8]>
<div class="cs_socials cs_socials_ie8" style="float: right">
<![endif]-->
<!--[if gt IE 8]><!---->
<div class="cs_socials" style="float: right">
<!--<![endif]-->\n
  <span class="cs_fb">
    <div class="fb-like" data-href="$_SESSION[cs_site_url]" data-send="false" data-layout="button_count" data-width="450" data-show-faces="false"></div>
  </span>
  &nbsp;
  <span class="cs_twitter">
    <a href="https://twitter.com/share" class="twitter-share-button" data-url="$_SESSION[cs_cur_url]" data-text="Share">Share</a>
  </span>
</div>\n
SOCIALS;
    }
    if (in_array($section, array('category', 'search'), true)) {
        $cs .= cs_show_paging($section, $user_id, $criteria,
            $p_data['totalp'], $_SESSION['cs_items_per_page'], $page);
    } else {
        $cs .= "<br />\n";
    }
    $cs .= "<hr />\n";
    
    $list_center_align =
        in_array($section, array('category', 'search'), true)
        && in_array($_SESSION['cs_switch_view'], array('ti', 'tdi'), true)
        || !in_array($section, array('category', 'search'), true)
        && in_array($_SESSION['cs_view_other'], array('ti', 'tdi'), true);
    if ($list_center_align) {
        $cs .= "<div style=\"text-align: center\">\n";
    }
    if (in_array($section, array('category', 'search'), true)
        && !empty($p_data['posts']))
    {
        $cur_sortby = (isset($_SESSION['cs_sortby']) ? $_SESSION['cs_sortby'] : 'rank');
        // Switch view
        $cs .= "<div class=\"cs_sview\">\n"
            . "<strong>Switch View</strong>\n"
            . "<select "
            . "onchange=\"cs_show_page('$section', '$user_id', '$criteria', "
            . "1, '$cur_sortby', this.value)\" "
            . "style=\"width: 17em\">\n";
        foreach ($_SESSION['cs_switch_view_vals'] as $val => $text) {
            $cs .= "<option value=\"$val\"";
            if ($val === $cur_view) $cs .= " selected=\"selected\"";
            $cs .= ">$text</option>\n";
        }
        $cs .= "</select>\n"
            . "</div>\n";
        
        // Sort criteria
        if ($section === 'category') {
            $cs .= "<div style=\"text-align: left\">"
                . "<strong>Sort</strong> ";
            $sortby_vals = array(
                'rank' => 'By Higher Rank',
                'gravity' => 'By Higher Gravity');
            if ($_SESSION['cs_show_price'] == '1') {
                $sortby_vals['price_h'] = 'High to Low Price';
                $sortby_vals['price_l'] = 'Low to High Price';
            } elseif (
                isset($_SESSION['cs_sortby'])
                && in_array($_SESSION['cs_sortby'], array('price_h', 'price_l'), true))
            {
                $_SESSION['cs_sortby'] = 'rank';
            }
            $cs .= "<select id=\"cs_sotrby\" "
                . "onchange=\"cs_show_page('$section', '$user_id', '$criteria', "
                . "1, this.value, '$cur_view')\" "
                . "style=\"width: 11em\">\n";
            foreach ($sortby_vals as $val => $text) {
                $cs .= "<option value=\"$val\"";
                if ($val === $cur_sortby) $cs .= " selected=\"selected\"";
                $cs .= ">$text</option>\n";
            }
            $cs .= "</select>\n"
                . "</div>\n";
        }
        $cs .= "<br /><br />\n";
    }
    
    $cs .= $item_list;
    if ($list_center_align) {
        $cs .= "</div>\n";
    }
    if (in_array($section, array('category', 'search'), true)) {
        $cs .= cs_show_paging($section, $user_id, $criteria,
            $p_data['totalp'], $_SESSION['cs_items_per_page'], $page);
    } else {
        $cs .= "<br />\n";
    }
    
    return array('output' => $cs, 'totalp' => $p_data['totalp']);
}

/**
* Return HTML product list to insert into post / page / etc
* 
* @param string $section
* @param string $criteria
* @param string $title
* @param int $product_number
*/
function cs_show_filter_contents($section, $criteria, $title, $product_number = null)
{
    $product_list = cs_show($section, $_SESSION['cs_user_id'], $criteria,
        1, $product_number);
    cs_get_css_js($product_list['totalp'], $_SESSION['cs_items_per_page']);
    
    $_SESSION['cs_cur_url'] = get_permalink();
    $_SESSION['cs_site_url'] = site_url();
    if (false === $_SESSION['cs_cur_url']) $_SESSION['cs_cur_url'] = $_SESSION['cs_site_url'];
    if ($section === 'category') {
        $_SESSION['cs_cur_url'] = cs_get_url($_SESSION['cs_cur_url'], array('cs_category' => $criteria));
    } elseif ($section === 'search') {
        $_SESSION['cs_cur_url'] = cs_get_url($_SESSION['cs_cur_url'], array('cs_keywords' => $criteria));
    }
    $_SESSION['cs_cur_url'] = htmlspecialchars($_SESSION['cs_cur_url'], ENT_QUOTES);
#die($_SESSION['cs_cur_url']);
    
    $res = <<<HD
<h2 class="cs_plugin_title">&raquo; $title</h2>
<br />

<!-- Facebook -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=137077062979348";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!-- Twitter -->
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

<div id="cs_loading_label" style="display: none; position: fixed; text-align: center">
  <h1 style="font-weight: bold">
    Loading the page...
  </h1>
</div>\n
HD;
    $res .= "<div id=\"cs_product_list\">\n"
        . "$product_list[output]\n"
        . "</div>\n";
    return $res;
}

/**
* Return HTML product list to insert into post / page / etc
* 
* @param array $attrs
* @return string
*/
function cs_show_filter($attrs = array())
{
    if (isset($_GET['cs_section'])) {
        $section = $_GET['cs_section'];
        $product_list_criteria = $title = '';
    } elseif (isset($_GET['cs_category'])) {
        $section = 'category';
        $selected_cat = $_GET['cs_category'];
        $category = cs_get_categories($selected_cat);
        $category = $category['selected_name'];
        $title = "Category: $category";
        $product_list_criteria = $selected_cat;
    } elseif (isset($_GET['cs_keywords'])) {
        $section = 'search';
        $product_list_criteria = $_GET['cs_keywords'];
        $title = "Search Results for \"".htmlspecialchars($product_list_criteria)."\"";
    }
    
    return cs_show_filter_contents($section, $product_list_criteria, $title);
}

/**
* Return BestSelling Products
* 
* @param array $attrs
* @return string
*/
function cs_show_bestselling($attrs = array())
{
    return cs_show_filter_contents('bestselling', '', 'Bestselling Books', $_SESSION['cs_bestselling_num']);
}

/**
* Return Featured Products
* 
* @param array $attrs
* @return string
*/
function cs_show_featured($attrs = array())
{
    if ($_SESSION['cs_featured_ids'] == '') {
        return '';
    }
    
    return cs_show_filter_contents(
        'featured',
        trim($_SESSION['cs_featured_ids']),
        'Featured Books',
        $_SESSION['cs_featured_num']);
}

/**
* Return Popular Products
* 
* @param array $attrs
* @return string
*/
function cs_show_popular($attrs = array())
{
    return cs_show_filter_contents('popular', '', 'Top New Releases in Books', $_SESSION['cs_popular_num']);
}

/**
* Return CSS style code for pagination buttons
* 
* @return string
*/
function cs_show_paging_css()
{
    wp_register_style('cs_paging', $_SESSION['cs_plugin_url'].'/paging.css');
    wp_enqueue_style('cs_paging');
}

/**
* Return HTML code for pagination buttons
* 
* @param string $section
* @param int $user_id
* @param string $criteria
* @param int $totalp
* @param int $items_per_page
* @param int $page
*/
function cs_show_paging($section, $user_id, $criteria, $totalp, $items_per_page, $page = 1)
{
    if ($totalp <= $items_per_page) {
        $html = '&nbsp;';
    } else {
        $totalp = (int)ceil($totalp / $items_per_page);
        $pages_to_show = array();
        if ($totalp < 3) $loop_end = $totalp+1;
        else $loop_end = 4;
        for ($i = 1; $i < $loop_end; $i++) $pages_to_show[$i] = true;
        $loop_end = $totalp-3;
        if ($loop_end < 0) $loop_end = 0;
        for ($i = $totalp; $i > $loop_end; $i--) $pages_to_show[$i] = true;
        if ($page > 2 && $page < $totalp-1) {
            for ($i = $page-1; $i < $page+2; $i++) {
                $pages_to_show[$i] = true;
            }
        }
        ksort($pages_to_show);
        
        $cur_sortby = (isset($_SESSION['cs_sortby']) ? $_SESSION['cs_sortby'] : 'rank');
        $cur_view = (in_array($section, array('category', 'search'), true)
            ? $_SESSION['cs_switch_view']
            : $_SESSION['cs_view_other']);
        
        $html = '';
        $prev_i = 0;
        foreach (array_keys($pages_to_show) as $i) {
            if ($i - $prev_i > 1) $html .= '... ';
            
            $html .= "<span class=\"cs_page_button";
            if ($page == $i) $html .= " cs_page_button_selected";
            $html .= "\" onclick=\"cs_show_page('$section', '$user_id', '$criteria', $i, "
                . "'$cur_sortby', '$cur_view'); return false\">";
            if ($page != $i) {
                $html .= "<a href=\"javascript:#\" >";
            }
            $html .= $i;
            if ($page != $i) $html .= "</a>";
            $html .= "</span> ";
            
            $prev_i = $i;
        }
    }
    
    return "<br />\n"
        . "<br />\n"
        . "<div style=\"text-align: right\">$html</div>";
}

?>
