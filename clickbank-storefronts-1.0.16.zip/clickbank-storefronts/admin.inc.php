<?php

require_once $GLOBALS['cs_plugin_dir'].'xmldb.inc.php';


/**
* Add plugin's options into DB and reset their values (called on plugin activation)
*/
function cs_activate()
{
    global $cs_options, $cs_ad_options;
    
    cs_add_options_to_db($cs_options, $cs_ad_options);
}

function cs_deactivate() {}

/**
* Add settings link on plugin page
* 
* @param array $links
*/
function cs_settings_link($links)
{
    $settings_link = '<a href="options-general.php?page=cs_menu">Settings</a>';
    array_unshift($links, $settings_link);
    
    return $links;
}

/**
* Add plugin's settings page to the WP admin panel menu
*/
function cs_add_to_menu()
{
    add_options_page(
        'Clickbank Storefronts',
        'Clickbank Storefronts',
        'manage_options',
        'cs_menu',
        'cs_option');
}

/**
* Echo plugin's settings page HTML code
*/
function cs_option()
{
    global $wpdb, $cs_options, $cs_ad_options;
    
    // Selects
    $cs_options['cs_rank']['cur_val'] = $_SESSION['cs_rank'];
    $cs_options['cs_gravity']['cur_val'] = $_SESSION['cs_gravity'];
    $cs_options['cs_products_page']['cur_val'] = $_SESSION['cs_products_page'];
    $cs_options['cs_cats_to_omit']['cur_val'] = $_SESSION['cs_cats_to_omit'];
    $cs_ad_options['cs_title_tag']['cur_val'] = $_SESSION['cs_title_tag'];
    $cs_ad_options['cs_subtitle_tag']['cur_val'] = $_SESSION['cs_subtitle_tag'];
    
    // Category Page
    $pages = get_pages();
    foreach ($pages as $page) {
        $cs_options['cs_products_page']['vals'][get_page_link($page->ID)]
            = $page->post_title;
    }
    // Categories to omit
    $cats = cs_get_categories();
    foreach ($cats['cats'] as $cat_id => $cat) {
        $cs_options['cs_cats_to_omit']['vals'][$cat_id] = $cat['name'];
    }
    
    echo "<h2>Clickbank Storefronts</h2>\n";
    
    if (@$_POST['cs_submit']) {
        if (!isset($_POST['cs_cats_to_omit'])) $_POST['cs_cats_to_omit'] = array();
        if ($_POST['cs_featured_ids'] != '') {
            $_POST['cs_featured_ids'] = explode(',', $_POST['cs_featured_ids']);
            $_POST['cs_featured_ids'] = array_map('trim', $_POST['cs_featured_ids']);
            $_POST['cs_featured_ids'] = implode(',', $_POST['cs_featured_ids']);
        }
        
        $opts = array('cs_options', 'cs_ad_options');
        foreach ($opts as $options_changed) {
            foreach ($$options_changed as $oname => $o) {
                if (isset($_POST[$oname]) || $o['type'] === 'checkbox') {
                    if ($oname !== 'cs_cats_to_omit') $oval = trim($_POST[$oname]);
                    else $oval = $_POST[$oname];
                    
                    switch ($o['type']) {
                        case 'checkbox':
                            if ($oval != '1') $oval = '0';
                            break;
                        case 'int':
                            if ($oval !== '') {
                                if (!ctype_digit("$oval")) {
                                    $oval = get_option($oname);
                                }
                            }
                            break;
                    }
                    
                    if ($oname === 'cs_cats_to_omit') {
                        $tmp = $oval;
                        $oval = array();
                        foreach ($tmp as $val) $oval[$val] = '1';
                    } elseif ($o['req'] && $oval === '') {
                        $oval = get_option($oname);
                    }
                    
                    update_option($oname, $wpdb->escape($oval));
                }
            }
        }
    }
    ?>
    
    <form name="cs_form" method="post" action="">
        <table class="form-table">
            <?php foreach ($cs_options as $oname => $o): ?>
                <?php if (true): ?>
                    <?php if ($oname === 'cs_view_other'): ?>
                        <tr valign="top">
                            <th colspan="2" scope="row">
                                <h2>Bestselling / Featured / Popular Product Lists</h2>
                                <p class="description">(Store Home Page Options)</p>
                            </th>
                        </tr>
                    <?php endif ?>
                    
                    <?php if ($oname === 'cs_cats_to_omit'): $oval = get_option($oname); ?>
                        <tr valign="top">
                            <th scope="row">
                                <label for="<?php echo $oname ?>"><?php echo $o['label'] ?></label>
                            </th>
                            <td>
                                <select name="<?php echo $oname ?>[]" id="<?php echo $oname ?>"
                                multiple="multiple">
                                    <?php foreach ($o['vals'] as $k => $v): ?>
                                        <option
                                        <?php if (isset($oval[(int)$k])): ?>
                                            selected="selected"
                                        <?php endif ?>
                                        value="<?php echo htmlspecialchars($k) ?>">
                                            <?php echo $v ?>
                                        </option>
                                    <?php endforeach ?>
                                </select>
                            </td>
                        </tr>
                    <?php elseif ($oname === 'cs_featured_ids'): ?>
                        <tr valign="top">
                            <th scope="row">
                                <label for="<?php echo $oname ?>"><?php echo $o['label'] ?></label>
                            </th>
                            <td>
                                <textarea style="width: 35em;" name="<?php echo $oname ?>"
                                id="<?php echo $oname ?>" class="regular-text"><?php echo get_option($oname) ?></textarea>
                                <p class="description">
                                    Fill this field to make Featured Products list work. Example: mikegeary1,1free,go4buck<br />
                                    50 IDs maximum.
                                </p>
                            </td>
                        </tr>
                    <?php elseif ($o['type'] === 'checkbox'): ?>
                        <tr valign="top">
                            <th scope="row"><?php echo $o['label'] ?></th>
                            <td>
                                <fieldset>
                                    <legend class="screen-reader-text">
                                        <span><?php echo $o['label'] ?></span>
                                    </legend>
                                    <label for="<?php echo $oname ?>">
                                        <input name="<?php echo $oname ?>" type="checkbox"
                                        id="<?php echo $oname ?>" value="1"
                                        <?php if(get_option($oname)=='1'): ?>
                                            checked="checked"
                                        <?php endif; ?> />
                                        Show
                                    </label>
                                </fieldset>
                            </td>
                        </tr>
                    <?php elseif ($o['type'] === 'select'): $oval = get_option($oname); ?>
                        <tr valign="top">
                            <th scope="row">
                                <label for="<?php echo $oname ?>"><?php echo $o['label'] ?></label>
                            </th>
                            <td>
                                <select name="<?php echo $oname ?>" id="<?php echo $oname ?>">
                                    <?php foreach ($o['vals'] as $k => $v): ?>
                                        <option
                                        <?php
                                        if (gettype($k) === 'integer'
                                            && $oval == $v || gettype($k) !== 'integer'
                                            && $oval == $k):
                                        ?>
                                            selected='selected'
                                        <?php endif ?>
                                        value='<?php
                                            echo htmlspecialchars(
                                                gettype($k) === 'integer' ? $v : $k)
                                        ?>'><?php echo $v ?></option>
                                    <?php endforeach ?>
                                </select>
                            </td>
                        </tr>
                    <?php elseif ($o['type'] === 'int'): ?>
                        <tr valign="top">
                            <th scope="row">
                                <label for="<?php echo $oname ?>"><?php echo $o['label'] ?></label>
                            </th>
                            <td>
                                <input style="width: 5em;" type="text"
                                value="<?php echo get_option($oname) ?>" name="<?php echo $oname ?>"
                                id="<?php echo $oname ?>" class="regular-text" />
                                <?php if ($oname == 'cs_user_id'): ?>
                                    <p class="description">
                                        If you don't have one, get one at
                                        <a href="http://www.cbproads.com/" target="_blank">CBproAds.com</a>
                                    </p>
                                <?php elseif (substr($oname, -4) == '_num'): ?>
                                    <p class="description">
                                        For first 2 view variants use a multiple of number of products per line
                                    </p>
                                <?php elseif ($oname == 'cs_image_margin'): ?>
                                    <p class="description">
                                        Affects <strong>Title & Img</strong>
                                        and <strong>Title, Desc & Img</strong> views
                                    </p>
                                <?php endif ?>
                            </td>
                        </tr>
                    <?php else: /* text */ ?>
                        <tr valign="top">
                            <th scope="row">
                                <label for="<?php echo $oname ?>"><?php echo $o['label'] ?></label>
                            </th>
                            <td>
                                <input style="width: 35em;" type="text"
                                value="<?php echo get_option($oname) ?>" name="<?php echo $oname ?>"
                                id="<?php echo $oname ?>" class="regular-text" />
                            </td>
                        </tr>
                    <?php endif ?>
                <?php endif ?>
            <?php endforeach ?>
        </table>
        
        <h2>Advanced Options</h2>
        Attention! Please remember the default values of these options
        before changing them to have ability to roll back your changes.
        <table class="form-table">
            <?php foreach ($cs_ad_options as $oname => $o): ?>
                <?php if ($o['type'] === 'select'): $oval = get_option($oname); ?>
                    <tr valign="top">
                        <th scope="row">
                            <label for="<?php echo $oname ?>"><?php echo $o['label'] ?></label>
                        </th>
                        <td>
                            <select name="<?php echo $oname ?>" id="<?php echo $oname ?>">
                                <?php foreach ($o['vals'] as $k => $v): ?>
                                    <option
                                    <?php if (
                                        gettype($k) === 'integer' && $oval == $v
                                        || gettype($k) !== 'integer' && $oval == $k):
                                    ?>
                                        selected='selected'
                                    <?php endif ?>
                                    value='<?php
                                        echo htmlspecialchars(gettype($k) === 'integer' ? $v : $k)
                                    ?>'><?php echo $v ?></option>
                                <?php endforeach ?>
                            </select>
                        </td>
                    </tr>
                <?php else: /* text */ ?>
                    <tr valign="top">
                        <th scope="row">
                            <label for="<?php echo $oname ?>"><?php echo $o['label'] ?></label>
                        </th>
                        <td>
                            <input style="width: 35em;" type="text"
                            value="<?php echo get_option($oname) ?>" name="<?php echo $oname ?>"
                            id="<?php echo $oname ?>" class="regular-text" />
                        </td>
                    </tr>
                <?php endif ?>
            <?php endforeach ?>
        </table>
        
        <p class="submit">
            <input type="submit" name="cs_submit" id="cs_submit" class="button-primary"
            value="Update" />
        </p>
    </form>
    
    <h2>Plugin Usage</h2>
    Please see <a href="http://www.cbproads.com/clickbank_storefront_wordpress_plugin.asp" target="_blank">this</a> URL.
    <?php
}

/**
 * Display JavaScript on the WP options page
 */
/*function cs_option_js()
{
    global $cs_options;
    
?>
<script type="text/javascript">
//<![CDATA[
    jQuery(document).ready(function($) {
        //var select = $('#cs_show_storefront_after_posts'),
        //    show_storefront_after_posts_change = function() {
        //        $('#cs_list_title').prop('disabled', select.val() == 'no');
        //    };
        //show_storefront_after_posts_change();
        //select.change(show_storefront_after_posts_change);
        //alert(jQuery('#cs_cats_to_omit').val());
        
        // Selects
        //<?php foreach ($cs_options['cs_cats_to_omit']['cur_val'] as $val => $tmp): ?>
            //jQuery('#cs_cats_to_omit option').val()
            //alert('<?php echo $val ?> => <?php echo $tmp ?>');
        //<?php endforeach ?>
    });
//]]>
</script>
<?php
}*/

?>