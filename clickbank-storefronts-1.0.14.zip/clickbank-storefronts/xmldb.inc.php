<?php

/**
* Add plugin options into WP
* 
* @param array $options
* @param array $ad_options
*/
function cs_add_options_to_db($options, $ad_options)
{
    global $wpdb;
    
    foreach ($options as $oname => $o) {
        update_option($oname, $wpdb->escape($o['default']));
    }
    // Advanced
    foreach ($ad_options as $oname => $o) {
        update_option($oname, $wpdb->escape($o['default']));
    }
}

/**
* Get site's domain name from Wordpress Address setting
*/
function cs_get_site_domain()
{
    static $domain = null;
    
    if ($domain === null) {
        $domain = substr(site_url('', 'http'), 7);
        if (false !== ($tmp = strpos($domain, '/'))) {
            $domain = substr($domain, 0, $tmp);
        }
    }
    
    return $domain;
}

/**
* Get URL with params (orig. URL can be with params already)
* 
* @param mixed $url
* @param mixed $params
*/
function cs_get_url($url, $params)
{
    $pos_q = strrpos($url, '?');
    if ($pos_q !== false) $url .= '&';
    else $url .= '?';
    
    foreach ($params as $k => &$v) {
        $v = rawurlencode($k).'='.rawurlencode($v);
    }
    $url .= implode('&', $params);
    
    return $url;
}

/**
* Get products page setting or '#'
*/
function cs_get_products_page($param_name = '', $param_val = '')
{
    #$page = get_option('cs_products_page');
    $page = $_SESSION['cs_products_page'];
    if ($page === '') {
        $page = '#';
    } else if ($param_name != '') {
        $pos_q = strrpos($page, '?');
        if ($pos_q !== false) $page .= '&';
        else $page .= '?';
        
        $page .= $param_name.'='.$param_val;
    }
    
    return $page;
}

/**
* Get products from the XML feed
* 
* @param int $user_id
* @param int $user_id
* @param int $criteria
* @param int $items_per_page
* @param int $page
* @param bool $include_css_js
* @return array
*/
function cs_get_items($section, $user_id, $criteria = null, $items_per_page,
    $page = 1, $include_css_js = false)
{
    if ($section === 'category') {
        $url = 'http://clickbankproads.com/xmlfeed/wp/main/cb_category_code.asp'
            . '?id='.$user_id
            . ($criteria != '' ? '&category_cd='.$criteria : '')
            . '&start='.(($page-1) * $items_per_page)
            . '&end='.$items_per_page
            . '&rank='.$_SESSION['cs_rank']
            . '&gravity='.$_SESSION['cs_gravity']
            . '&sortby='.(isset($_SESSION['cs_sortby']) ? $_SESSION['cs_sortby'] : 'rank');
        $cur_view = $_SESSION['cs_switch_view'];
        $show_more_link = false;
    } elseif ($section === 'search') {
        $url = 'http://clickbankproads.com/xmlfeed/wp/main/cb_search.asp'
            . '?id='.$user_id
            . '&keywords='.rawurlencode($criteria)
            . '&start='.(($page-1) * $items_per_page)
            . '&end='.$items_per_page;
        $cur_view = $_SESSION['cs_switch_view'];
        $show_more_link = false;
    } elseif ($section === 'bestselling') {
        $url = 'http://clickbankproads.com/xmlfeed/wp/main/cb_gravity.asp'
            . '?id='.$user_id
            . '&no_of_products='.$items_per_page;
        $cur_view = $_SESSION['cs_view_other'];
        $show_more_link = true;
    } elseif ($section === 'featured') {
        $url = 'http://clickbankproads.com/xmlfeed/wp/main/cb_featured.asp'
            . '?id='.$user_id
            . '&no_of_products='.$items_per_page
            . '&product_ids='.rawurlencode($criteria);
        $cur_view = $_SESSION['cs_view_other'];
        $show_more_link = true;
    } elseif ($section === 'popular') {
        $url = 'http://clickbankproads.com/xmlfeed/wp/main/cb_popular.asp'
            . '?id='.$user_id
            . '&no_of_products='.$items_per_page;
        $cur_view = $_SESSION['cs_view_other'];
        $show_more_link = true;
    }
    
    // Answer when there is nothing to show
    if ($section === 'search') {
        $empty_answer = array('posts' => array(), 'totalp' => 0);
    } else {
        $empty_answer = array(
            'posts' => array(
                array(
                    'post_title' => cs_product_title_fmt('Sorry', '#', $include_css_js),
                    'post_content' => 'No products in this list yet.')),
            'totalp' => 1);
    }
    
    // Load data
    $doc = new DOMDocument();
    if (false === @$doc->load($url)) return $empty_answer;
    $items = $doc->getElementsByTagName("item");
    if (0 === $items->length) return $empty_answer;
    
    $totalp = cs_cdata(
        $items
        ->item(0)->getElementsByTagName("totalp")
        ->item(0)->nodeValue);
    
    $cat_link = cs_get_products_page('cs_category', '');
    
    $count = 0;
    $item_list = array();
    $first = true;
    foreach ($items as $item) {
        // Title
        $paths = $item->getElementsByTagName("title");
        $title = htmlspecialchars(cs_cdata($paths->item(0)->nodeValue));
        
        // URL
        $paths = $item->getElementsByTagName("affiliate");
        $mem = cs_cdata($paths->item(0)->nodeValue);
        $paths = $item->getElementsByTagName("ids");
        $tar = cs_cdata($paths->item(0)->nodeValue);
        $paths = $item->getElementsByTagName("niche");
        $niche = cs_cdata($paths->item(0)->nodeValue);
        /*$link = htmlspecialchars($_SESSION['cs_plugin_url'].'/product/index.php/'
            . rawurlencode(str_replace(array('?', '/'), array('.', '.'), $title)).'/'
            . $user_id.'/'
            . $mem.'/'
            . $tar.'/'
            . $niche.'/');*/
        $link = htmlspecialchars($_SESSION['cs_plugin_url'].'/product.php'
            . '?memnumber='.$user_id
            . '&mem='.$mem
            . '&tar='.$tar
            . '&niche='.$niche);
        
        // Descriptions
        $paths = $item->getElementsByTagName("description");
        $description = htmlspecialchars(cs_cdata($paths->item(0)->nodeValue));
        $paths = $item->getElementsByTagName("mdescr");
        $mdescr = htmlspecialchars(cs_cdata($paths->item(0)->nodeValue));
        
        // Images
        $paths = $item->getElementsByTagName("images");
        $imageFilename = cs_cdata($paths->item(0)->nodeValue);
        if ($imageFilename != '' && $imageFilename != 'no') {
            $image = 'http://cbproads.com/clickbankstorefront/v4/send_binary.asp'
                . '?Path=D:/hshome/cbproads/cbproads.com/cbbanners/'
                . $imageFilename.'&resize='.$_SESSION['cs_image_size'];
            $image = htmlspecialchars($image);
            $imageFull = 'http://cbproads.com/clickbankstorefront/v4/send_binary.asp'
                . '?Path=D:/hshome/cbproads/cbproads.com/cbbanners/'.$imageFilename.'&resize=default';
            $imageFull = htmlspecialchars($imageFull);
        } else {
            unset($image, $imageFull);
        }
        $paths = $item->getElementsByTagName("altimage");
        $altimageFilename = cs_cdata($paths->item(0)->nodeValue);
        if ($altimageFilename != '' && $altimageFilename != 'no') {
            $altimage = 'http://cbproads.com/clickbankstorefront/v4/send_binary.asp'
                . '?Path=D:/hshome/cbproads/cbproads.com/cbbanners/alter/'
                . $altimageFilename.'&resize='.$_SESSION['cs_image_size'];
            $altimage = htmlspecialchars($altimage);
            $altimageFull = 'http://cbproads.com/clickbankstorefront/v4/send_binary.asp'
                . '?Path=D:/hshome/cbproads/cbproads.com/cbbanners/alter/'
                . $altimageFilename.'&resize=default';
            $altimageFull = htmlspecialchars($altimageFull);
        } else {
            unset($altimage, $altimageFull);
        }
        
        // Price
        $paths = $item->getElementsByTagName("price");
        $price = htmlspecialchars(cs_cdata($paths->item(0)->nodeValue));
        
        // Rank & Gravity
        $paths = $item->getElementsByTagName("rank");
        $rank = cs_cdata($paths->item(0)->nodeValue);
        $paths = $item->getElementsByTagName("gravity");
        $gravity = cs_cdata($paths->item(0)->nodeValue);
        
        if ($show_more_link) {
            // Category
            $paths = $item->getElementsByTagName("category");
            $category = cs_cdata($paths->item(0)->nodeValue);
        }
        
        // Add record
        $list_item = array('target_url' => $link,
            'post_title' => cs_product_title_fmt($title, $link, $include_css_js));
        
        if ($cur_view === 'ti') {
            $list_item['post_content'] =
                (isset($altimage) || isset($image)
                    ? "<div class=\"cs_image_holder\" style=\"text-align: center\">"
                    . (isset($altimage)
                        ? "<a class=\"cs_image_$count cs_preview\" "
                        . "title=\"".htmlspecialchars($title)."\" "
                        . "href=\"#\" src=\"$altimageFull\" "
                        . "index=\"cs_image_$count\" rel=\"nofollow\" "
                        . "onclick=\"window.open('$link'); return false\">"
                        . "<img alt=\"\" src=\"$altimage\" "
                        . "style=\"margin-right: 10px\" /></a>\n"
                        : (isset($image)
                            ? "<a class=\"cs_image_$count cs_preview\" "
                            . "title=\"".htmlspecialchars($title)."\" "
                            . "href=\"#\" src=\"$imageFull\" "
                            . "index=\"cs_image_$count\" rel=\"nofollow\" "
                            . "onclick=\"window.open('$link'); return false\">"
                            . "<img alt=\"cs_image_$count\" src=\"$image\" "
                            . "style=\"margin-right: 10px\" /></a>"
                            : '')
                        )
                    . "</div>"
                    : '')
                . ($_SESSION['cs_show_price'] == '1' && $price != ''
                    ? "<div style=\"font-size: 120%; padding: 0.4em 0\">Price: \$$price</div>"
                    : '')
                /*. "<div align=\"center\" style=\"font-size: 150%; font-weight: bold; "
                . "border: solid 1px #808080; padding: 0.4em;\">"
                . "<a target=\"_blank\" href=\"$link\" rel=\"nofollow\">Visit Website</a>"
                . "</div>"*/
                . "</div>\n" // cs_ip_td
                . "</div>\n" // cs_ip_tr
                . "<div class=\"cs_ip_tr\">\n"
                . "<div class=\"cs_ip_td\" style=\"vertical-align: bottom; text-align: left\">\n"
                . "<div class=\"cs_rank_gravity\" style=\"padding-top: 0.3em\">\n"
                . "Rank: $rank"
                . "<div style=\"float: right; text-align: right\">\n"
                . "Gravity: $gravity"
                . ($show_more_link
                    ? "<br />\n<a href=\"$cat_link$category\">Show more products</a>"
                    : '')
                . "</div>"
                . "</div>";
        } elseif ($cur_view === 'tdi') {
            $list_item['post_content'] =
                "$description<br /><br />\n"
                . (isset($altimage) || isset($image)
                    ? "<div class=\"cs_image_holder\" style=\"text-align: center\">"
                    . (isset($altimage)
                        ? "<a class=\"cs_image_$count cs_preview\" "
                        . "title=\"".htmlspecialchars($title)."\" "
                        . "href=\"#\" src=\"$altimageFull\" "
                        . "index=\"cs_image_$count\" rel=\"nofollow\" "
                        . "onclick=\"window.open('$link'); return false\">"
                        . "<img alt=\"\" src=\"$altimage\" "
                        . "style=\"margin-right: 10px\" /></a>\n"
                        : (isset($image)
                            ? "<a class=\"cs_image_$count cs_preview\" "
                            . "title=\"".htmlspecialchars($title)."\" "
                            . "href=\"#\" src=\"$imageFull\" "
                            . "index=\"cs_image_$count\" rel=\"nofollow\" "
                            . "onclick=\"window.open('$link'); return false\">"
                            . "<img alt=\"cs_image_$count\" src=\"$image\" "
                            . "style=\"margin-right: 10px\" /></a>"
                            : '')
                        )
                    . "</div>"
                    : '')
                . ($_SESSION['cs_show_price'] == '1' && $price != ''
                    ? "<div style=\"font-size: 120%; padding: 0.4em 0\">Price: \$$price</div>"
                    : '')
                /*. "<div align=\"center\" style=\"font-size: 150%; font-weight: bold; "
                . "border: solid 1px #808080; padding: 0.4em;\">"
                . "<a target=\"_blank\" href=\"$link\" rel=\"nofollow\">Visit Website</a>"
                . "</div>"*/
                . "</div>\n" // cs_ip_td
                . "</div>\n" // cs_ip_tr
                . "<div class=\"cs_ip_tr\">\n"
                . "<div class=\"cs_ip_td\" style=\"vertical-align: bottom; text-align: left\">\n"
                . "<div class=\"cs_rank_gravity\" style=\"padding-top: 0.3em\">\n"
                . "Rank: $rank"
                . "<div style=\"float: right; text-align: right\">\n"
                . "Gravity: $gravity"
                . ($show_more_link
                    ? "<br />\n<a href=\"$cat_link$category\">Show more products</a>"
                    : '')
                . "</div>"
                . "</div>";
        } elseif ($cur_view === 'tdli') {
            $list_item['post_content'] =
                "<div>\n"
                . "<$_SESSION[cs_subtitle_tag]"
                . ($_SESSION['cs_subtitle_style'] != ''
                    ? " style=\""
                    . ($_SESSION['cs_subtitle_tag'] == 'strong' ? "display: inline-block; " : '')
                    . "$_SESSION[cs_subtitle_style]\""
                    : '')
                . ">$description</$_SESSION[cs_subtitle_tag]>"
                . ($_SESSION['cs_subtitle_tag'] == 'strong' ? "<br />" : '')
                . "\n"
                . (isset($altimage) || isset($image)
                    ? "<span class=\"cs_image_holder\" style=\"float: left\">"
                    . (isset($altimage)
                        ? "<a class=\"cs_image_$count cs_preview\" "
                        . "title=\"".htmlspecialchars($title)."\" "
                        . "href=\"#\" src=\"$altimageFull\" "
                        . "index=\"cs_image_$count\" rel=\"nofollow\" "
                        . "onclick=\"window.open('$link'); return false\">"
                        . "<img alt=\"\" src=\"$altimage\" "
                        . "style=\"margin-right: 10px\" /></a>\n"
                        : (isset($image)
                            ? "<a class=\"cs_image_$count cs_preview\" "
                            . "title=\"".htmlspecialchars($title)."\" "
                            . "href=\"#\" src=\"$imageFull\" "
                            . "index=\"cs_image_$count\" rel=\"nofollow\" "
                            . "onclick=\"window.open('$link'); return false\">"
                            . "<img alt=\"cs_image_$count\" src=\"$image\" "
                            . "style=\"margin-right: 10px\" /></a>"
                            : '')
                        )
                    . "</span>"
                    : '')
                . "<div style=\"text-align: justify\">"
                . $mdescr
                . "</div>"
                /*. "<div style=\"float: right; font-size: 150%; font-weight: bold; "
                . "border: solid 1px #808080; padding: 0.4em;\">"
                . "<a target=\"_blank\" href=\"$link\" rel=\"nofollow\">Visit Website</a>"
                . "</div>"*/
                . "<div class=\"cs_rank_gravity\" style=\"padding-top: 0.6em\">\n"
                . ($_SESSION['cs_show_price'] == '1' && $price != ''
                    ? "<div style=\"font-size: 120%\">Price: \$$price</div>"
                    . "<div style=\"padding-top: 0.5em\">\n"
                    : '')
                . "<div style=\"text-align: right\" style=\"float: right\">\n"
                . "Gravity: $gravity"
                . ($show_more_link
                    ? "<br />\n<a href=\"$cat_link$category\">Show more products</a>"
                    : '')
                . "</div>"
                . "Rank: $rank"
                . ($_SESSION['cs_show_price'] == '1' && $price != ''
                    ? "</div>" : '')
                . "</div>"
                . "<div style=\"clear: both\"></div>"
                . "</div>\n";
        } elseif ($cur_view === 'td') {
            $list_item['post_content'] =
                "<div>\n"
                /*. "<$_SESSION[cs_subtitle_tag]"
                . ($_SESSION['cs_subtitle_style'] != ''
                    ? " style=\""
                    . ($_SESSION['cs_subtitle_tag'] == 'strong' ? "display: inline-block; " : '')
                    . "$_SESSION[cs_subtitle_style]\""
                    : '')
                . ">$description</$_SESSION[cs_subtitle_tag]>"
                . ($_SESSION['cs_subtitle_tag'] == 'strong' ? "<br />" : '')
                . "\n"*/
                . "$description\n"
                /*. "<div style=\"float: right; font-size: 150%; font-weight: bold; "
                . "border: solid 1px #808080; padding: 0.4em;\">"
                . "<a target=\"_blank\" href=\"$link\" rel=\"nofollow\">Visit Website</a>"
                . "</div>"*/
                . "<div class=\"cs_rank_gravity\" style=\"padding-top: 1em\">\n"
                . ($_SESSION['cs_show_price'] == '1' && $price != ''
                    ? "Price: \$$price"
                    . "<div style=\"padding-top: 0.5em\">\n"
                    : '')
                . "<div style=\"text-align: right\" style=\"float: right\">\n"
                . "Gravity: $gravity"
                . ($show_more_link
                    ? "<br />\n<a href=\"$cat_link$category\">Show more products</a>"
                    : '')
                . "</div>"
                . "Rank: $rank"
                . ($_SESSION['cs_show_price'] == '1' && $price != ''
                    ? "</div>" : '')
                . "</div>"
                . "<div style=\"clear: both\"></div>"
                . "</div>\n";
        }
        
        $item_list[] = $list_item;
        $count++;
    }
    
    return array('posts' => $item_list, 'totalp' => $totalp);
}

/**
* Get products from the XML feed
* 
* @param int $selected_cat
* @return array
*/
function cs_get_categories($selected_cat = null)
{
    static $item_list = null;
    
    if ($item_list === null) {
        $url = 'http://clickbankproads.com/xmlfeed/wp/main/categories.asp';
        
        $error_answer = array(
            0 => array(
                'name' => 'Categories',
                'subcats' => array('Sorry, no categories for now.')));
        $xml = @simplexml_load_file($url);
        if (false === $xml) return $error_answer;
        $items = $xml->channel[0]->item;
        if (0 === count($items)) return $error_answer;
        
        $item_list = array(
            'selected_id' => null,
            'selected_name' => null,
            'cats' => array());
        foreach ($items as $item) {
            // Get data
            $cat_id = (int)$item->mainhead[0];
            $cat_name = (string)$item->mainhead_name[0];
            $subcat_id = (int)$item->subhead[0];
            $subcat_name = (string)$item->subhead_name[0];
            
            // Add record
            if (!isset($item_list['cats'][$cat_id])) {
                $item_list['cats'][$cat_id] = array(
                    'name' => $cat_name,
                    'thumbnail_main' => (string)$item->thumbnail_main[0],
                    'thumbnail_grey' => (string)$item->thumbnail_grey[0],
                    'thumbnail_small_main' => (string)$item->thumbnail_small_main[0],
                    'thumbnail_small_grey' => (string)$item->thumbnail_small_grey[0],
                    'subcats' => array());
            }
            $item_list['cats'][$cat_id]['subcats'][$subcat_id] = array(
                'name' => $subcat_name);
            
            // Check if selected
            if ($subcat_id == $selected_cat) {
                $item_list['cats'][$cat_id]['subcats'][$subcat_id]['selected'] = true;
                $item_list['selected_id'] = $subcat_id;
                $item_list['selected_name'] = $subcat_name;
            }
        }
    }
    
    return $item_list;
}

?>
